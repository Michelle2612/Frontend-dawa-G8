import { RouterModule, Routes } from '@angular/router';
import { BodyComponent } from './components/body/body.component';
import { LoginComponent } from './components/login/login.component';
import { NgModule } from '@angular/core';

import { ClientesComponent } from './components/clientes/clientes.component';
import { ProveedorComponent } from './components/proveedor/proveedor.component';
import { TransporteComponent } from './components/transporte/transporte.component';
import { ProductoComponent } from './components/producto/producto.component';
import { CatalogoComponent } from './components/catalogo/catalogo.component';
import { ContactoComponent } from './components/contacto/contacto.component';
import { AdministradorComponent } from './components/administrador/administrador.component';
import { AdminClientesComponent } from './components/admin-clientes/admin-clientes.component';
import { AdminProductoComponent } from './components/admin-producto/admin-producto.component';
import { AdminTransporteComponent } from './components/admin-transporte/admin-transporte.component';
import { AdminProveedorComponent } from './components/admin-proveedor/admin-proveedor.component';
import { ReservacionComponent } from './components/reservacion/reservacion.component';
import { OrdenDeCompraComponent } from './components/orden-de-compra/orden-de-compra.component';
import { InventarioComponent } from './components/inventario/inventario.component';
import { EnviosComponent } from './components/envios/envios.component';
import { SolicitudComponent } from './components/solicitud/solicitud.component';
import { authGuard } from './services/login/auth.guard';
import { ModificarClienteComponent } from './components/modificar-cliente/modificar-cliente.component';
import { ModificarEmpresaComponent } from './components/modificar-empresa/modificar-empresa.component';
import { ModificarProductoComponent } from './components/modificar-producto/modificar-producto.component';
import { ModificarProveedorComponent } from './components/modificar-proveedor/modificar-proveedor.component';
import { AdminContactoComponent } from './components/admin-contacto/admin-contacto.component';
import { ModificarContactoComponent } from './components/modificar-contacto/modificar-contacto.component';

export const routes: Routes = [

    { path: '', redirectTo: 'body', pathMatch: 'full' },
    { path: 'body', component: BodyComponent },
    { path: 'login', component: LoginComponent },
    {path: 'cliente', component: ClientesComponent, canActivate: [authGuard] },
    { path: 'proveedor', component: ProveedorComponent , canActivate: [authGuard] },
    { path: 'transporte', component: TransporteComponent , canActivate: [authGuard] },
    { path: 'producto', component: ProductoComponent , canActivate: [authGuard] },
    { path: 'catalogo', component: CatalogoComponent },
    { path: 'contacto', component: ContactoComponent },   
    { path: 'reservacion', component: ReservacionComponent },   
    { path: 'compra', component: OrdenDeCompraComponent }, 
    { path: 'envios', component: EnviosComponent }, 
    { path: 'solicitud', component: SolicitudComponent }, 
    { path: 'adminCliente', component: AdminClientesComponent,},
    { path: 'adminProveedor', component: AdminProveedorComponent },
    { path: 'adminTransporte', component: AdminTransporteComponent },
    { path: 'adminProducto', component: AdminProductoComponent },
    { path: 'inventario', component: InventarioComponent },
    { path: 'modificarC/:id', component: ModificarClienteComponent },
    { path: 'modificarE/:id', component: ModificarEmpresaComponent },
    { path: 'modificarPO/:id', component: ModificarProductoComponent },
    { path: 'modificarP/:id', component: ModificarProveedorComponent },
    { path: 'adminContacto', component: AdminContactoComponent },
    { path: 'modificarCon/:id', component: ModificarContactoComponent },
    {
        path: 'admin', component: AdministradorComponent,
     
    },


    { path: '**', redirectTo: 'body', pathMatch: 'full' },

  




];
@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
  })
  export class AppRoutingModule { }
