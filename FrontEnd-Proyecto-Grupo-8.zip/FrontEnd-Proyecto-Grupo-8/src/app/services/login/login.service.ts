import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';

import { firstValueFrom, Observable } from 'rxjs';
import { Login } from '../../interfaces/login';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  private myAppUrl: string = environment.endpoint;
  private myApiUrl: string = 'api/Login/';

  constructor(private http: HttpClient) { }
  login(correo: string, contrasenia: string): Observable<Login> {
    return this.http.get<Login>(`${this.myAppUrl}${this.myApiUrl}byCorreo/${correo}/${contrasenia}`);
  }
}

