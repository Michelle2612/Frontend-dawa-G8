import { inject, Injectable } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

export const authGuard: CanActivateFn = (route , state) => {
  const authService = inject(AuthService); // Obtén el servicio de autenticación
  const router = inject(Router); // Obtén el enrutador

  return authService.user$.pipe(
     map(user => {
      if (!user) {
        //router.navigate(['/']);
        return true;
      } else if (user.tipoUsuario === 'Cliente') {
        router.navigate(['/catalogo']);
        return false;
      } else if (user.tipoUsuario === 'Proveedor') {
        router.navigate(['/producto']);
        return false;
      } else if (user.tipoUsuario === 'EmpresaTransporte') {
        router.navigate(['/transporte']);
        return false;
      } else {
        return true;
      }
    })
  );
};

