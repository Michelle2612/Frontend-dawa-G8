import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Login } from '../../interfaces/login';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private userSubject = new BehaviorSubject<Login | null>(null);
  user$ = this.userSubject.asObservable();

  setUser(user: Login) {
    this.userSubject.next(user);
  }

  clearUser() {
    this.userSubject.next(null);
  }
  logout() {
    this.clearUser();
  }
  isAuthenticated(): boolean {
    return this.userSubject.value !== null;
  }

  isCliente(): boolean {
    return this.userSubject.value?.tipoUsuario === 'Cliente';
  }
}
