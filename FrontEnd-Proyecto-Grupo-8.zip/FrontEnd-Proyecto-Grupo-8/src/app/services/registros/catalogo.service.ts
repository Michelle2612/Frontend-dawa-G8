import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Catalogo } from '../../interfaces/catalogo';
import { Productos } from '../../interfaces/productos';

@Injectable({
  providedIn: 'root'
})
export class CatalogoService {

  private myAppUrl: string = environment.endpoint;
  private myApiUrl: string = 'api/Catalogo/';

  constructor(private http: HttpClient) { }

  addCatalogo(catalogo: Catalogo): Observable<number> {
    return this.http.post<number>(`${this.myAppUrl}${this.myApiUrl}`, catalogo);
  }

  getCatalogoByCategoria(categoria: string): Observable<Catalogo[]> {
    return this.http.get<Catalogo[]>(`${this.myAppUrl}${this.myApiUrl}categoria/${categoria}`);
  }
}
