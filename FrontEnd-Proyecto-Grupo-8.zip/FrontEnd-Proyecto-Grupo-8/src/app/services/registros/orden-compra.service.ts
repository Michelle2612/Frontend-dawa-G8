import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { OrdenPago } from '../../interfaces/ordenPago';
import { Observable } from 'rxjs';
import { Cliente } from '../../interfaces/cliente';
import { Productos } from '../../interfaces/productos';

@Injectable({
  providedIn: 'root'
})
export class OrdenCompraService {

  private myAppUrl: string = environment.endpoint;
  private myApiUrl: string = 'api/OrdenPago/';

  constructor(private http: HttpClient) { }

  addOrdenPago(ordenpago: OrdenPago): Observable<number> {
    return this.http.post<number>(`${this.myAppUrl}${this.myApiUrl}`, ordenpago);
  }

  getOrdenPago(): Observable<OrdenPago[]> { 
    return this.http.get<OrdenPago[]>(`${this.myAppUrl}${this.myApiUrl}`);
  }
  getOrdenPagoByCodigo(codigo: number): Observable<any> {
    return this.http.get<any>(`${this.myAppUrl}${this.myApiUrl}codigo/${codigo}`);
  }

  getClienteById(clienteId: string): Observable<Cliente> {
    return this.http.get<Cliente>(`${this.myAppUrl}${this.myApiUrl}Clientes/${clienteId}`);
  }
  getProductosByCliente(clienteId: string): Observable<Productos[]> {
    return this.http.get<Productos[]>(`${this.myAppUrl}${this.myApiUrl}Clientes/${clienteId}`);
  }

  getOrdenById(clienteId: number): Observable<OrdenPago> {
    return this.http.get<OrdenPago>(`${this.myAppUrl}${this.myApiUrl}${clienteId}`);
  }
 
  modificarOrden(cliente: OrdenPago): Observable<number>{
    return this.http.put<number>(`${this.myAppUrl}${this.myApiUrl}${cliente.ordenPagoId}`,cliente);
  }
  eliminarOrden(id: number): Observable<void>{
    return this.http.delete<void>(`${this.myAppUrl}${this.myApiUrl}${id}`);
  }
  getOrdenT(): Observable<any> { 
    return this.http.get<any>(`${this.myAppUrl}${this.myApiUrl}`);
  }
}
