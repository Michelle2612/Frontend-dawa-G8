import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Productos } from '../../interfaces/productos';

@Injectable({
  providedIn: 'root'
})
export class ProductosService {

  private myAppUrl: string = environment.endpoint;
  private myApiUrl: string = 'api/Producto/';

  constructor(private http: HttpClient) { }

  addProducto(productos: Productos): Observable<any> {
    const formData = new FormData();
    formData.append('nombreProducto', productos.nombreProducto);
    formData.append('cantidad', productos.cantidad.toString());
    formData.append('precio', productos.precio.toString());
    formData.append('categoria', productos.categoria);
    formData.append('descripcion', productos.descripcion);
    formData.append('proveedorId', productos.proveedorId.toString());
    
    if (productos.imagenProducto) {
      formData.append('imagenProducto', productos.imagenProducto);
      console.log('Imagen producto:', productos.imagenProducto); // Agrega este console.log
    }
    
    return this.http.post<any>(`${this.myAppUrl}${this.myApiUrl}`, formData);
  }
  
  getProductosByCategoria(categoria: string): Observable<any> {
    return this.http.get<any>(`${this.myAppUrl}${this.myApiUrl}categoria/${categoria}`);
  }
  getProductoImagenUrl(productoId: number): string {
    return `${this.myAppUrl}${this.myApiUrl}${productoId}/imagen`;
  }
  getProducto(): Observable<Productos[]> { 
    return this.http.get<Productos[]>(`${this.myAppUrl}${this.myApiUrl}`);
  }
  getProductoById(clienteId: number): Observable<Productos> {
    return this.http.get<Productos>(`${this.myAppUrl}${this.myApiUrl}${clienteId}`);
  }
 
  modificarProducto(cliente: Productos): Observable<number>{
    return this.http.put<number>(`${this.myAppUrl}${this.myApiUrl}${cliente.productoId}`,cliente);
  }
  eliminarProducto(id: number): Observable<void>{
    return this.http.delete<void>(`${this.myAppUrl}${this.myApiUrl}${id}`);
  }
  getProductoT(): Observable<any> { 
    return this.http.get<any>(`${this.myAppUrl}${this.myApiUrl}`);
  }
}



  /*addProducto(productos: Productos): Observable<any> {
    const formData = new FormData();
    formData.append('nombreProducto', productos.nombreProducto);
    formData.append('cantidad', productos.cantidad.toString());
    formData.append('precio', productos.precio.toString());
    formData.append('categoria', productos.categoria);
    formData.append('descripcion', productos.descripcion);
    formData.append('proveedorId', productos.proveedorId.toString());

    if (productos.imagenProducto) {
      formData.append('imagenProducto', productos.imagenProducto);
    }

    return this.http.post<any>(`${this.myAppUrl}${this.myApiUrl}`, formData);
  }*/