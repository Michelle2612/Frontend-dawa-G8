import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { SolicitudOrden } from '../../interfaces/solicitudOrden';
import { BehaviorSubject, Observable } from 'rxjs';
import { Productos } from '../../interfaces/productos';

@Injectable({
  providedIn: 'root'
})
export class SolicitudOrdenService {
  
  
  private myAppUrl: string = environment.endpoint;
  private myApiUrl: string = 'api/SolicitudPago/';

  constructor(private http: HttpClient) { }
  
  private productosSubject = new BehaviorSubject<Productos[]>([]);

  agregarProducto(producto: Productos): void {
    const currentProductos = this.productosSubject.value;
    currentProductos.push(producto);
    this.productosSubject.next(currentProductos); 
  }

  getProductos(): Observable<Productos[]> {
    return this.productosSubject.asObservable(); 
  }

  getProductosSnapshot(): Productos[] {
    return this.productosSubject.value.slice(); 
  }
  getSolicitudByCodigo(codigo: number): Observable<SolicitudOrden> {
    return this.http.get<SolicitudOrden>(`${this.myAppUrl}${this.myApiUrl}codigo/${codigo}`);
  }
}


