import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { EmpresaTransporte } from '../../interfaces/empresaTransporte';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmpresaService {
  
  private myAppUrl: string = environment.endpoint;
  private myApiUrl: string = 'api/EmpresaTransporte/';

  constructor(private http: HttpClient) { }

  addEmpresa(empresa: EmpresaTransporte): Observable<number> {
    return this.http.post<number>(`${this.myAppUrl}${this.myApiUrl}`, empresa);
  }
  getEmpresa(): Observable<EmpresaTransporte[]> { 
    return this.http.get<EmpresaTransporte[]>(`${this.myAppUrl}${this.myApiUrl}`);
  }

  getEmpresaT(): Observable<any> { 
    return this.http.get<any>(`${this.myAppUrl}${this.myApiUrl}`);
  }
  getEmpresaById(clienteId: number): Observable<EmpresaTransporte> {
    return this.http.get<EmpresaTransporte>(`${this.myAppUrl}${this.myApiUrl}${clienteId}`);
  }
 
  modificarEmpresa(cliente: EmpresaTransporte): Observable<number>{
    return this.http.put<number>(`${this.myAppUrl}${this.myApiUrl}${cliente.empresaTransporteId}`,cliente);
  }
  eliminarEmpresa(id: number): Observable<void>{
    return this.http.delete<void>(`${this.myAppUrl}${this.myApiUrl}${id}`);
  }
}
