import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Contacto } from '../../interfaces/contacto';

@Injectable({
  providedIn: 'root'
})
export class ContactoService {

  private myAppUrl: string = environment.endpoint;
  private myApiUrl: string = 'api/Contacto/';

  constructor(private http: HttpClient) { }

  addContacto(contacto: Contacto): Observable<number> {
    return this.http.post<number>(`${this.myAppUrl}${this.myApiUrl}`, contacto);
  }
  getContactoById(clienteId: number): Observable<Contacto> {
    return this.http.get<Contacto>(`${this.myAppUrl}${this.myApiUrl}${clienteId}`);
  }
 
  modificarContacto(cliente: Contacto): Observable<number>{
    return this.http.put<number>(`${this.myAppUrl}${this.myApiUrl}${cliente.contactoId}`,cliente);
  }
  eliminarContacto(id: number): Observable<void>{
    return this.http.delete<void>(`${this.myAppUrl}${this.myApiUrl}${id}`);
  }
  getContactoT(): Observable<any> { 
    return this.http.get<any>(`${this.myAppUrl}${this.myApiUrl}`);
  }
}
