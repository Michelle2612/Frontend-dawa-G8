import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable , of} from 'rxjs';
import { Proveedor } from '../../interfaces/proveedor';

@Injectable({
  providedIn: 'root'
})
export class ProveedorService {

  private myAppUrl: string = environment.endpoint;
  private myApiUrl: string = 'api/Proveedor/';

  constructor(private http: HttpClient) { }

  addProveedor(proveedor: Proveedor): Observable<number> {
    return this.http.post<number>(`${this.myAppUrl}${this.myApiUrl}`, proveedor);
  }
  getPorveedor(): Observable<any> { 
    return this.http.get<any>(`${this.myAppUrl}${this.myApiUrl}`);
  }

  getProveedores(): Observable<Proveedor[]> { 
    return this.http.get<Proveedor[]>(`${this.myAppUrl}${this.myApiUrl}`);
  }
  getProveedorById(clienteId: number): Observable<Proveedor> {
    return this.http.get<Proveedor>(`${this.myAppUrl}${this.myApiUrl}${clienteId}`);
  }
 
  modificarProveedor(cliente: Proveedor): Observable<number>{
    return this.http.put<number>(`${this.myAppUrl}${this.myApiUrl}${cliente.proveedorId}`,cliente);
  }
  eliminarProveedor(id: number): Observable<void>{
    return this.http.delete<void>(`${this.myAppUrl}${this.myApiUrl}${id}`);
  }
  getProveedorT(): Observable<any> { 
    return this.http.get<any>(`${this.myAppUrl}${this.myApiUrl}`);
  }

}
