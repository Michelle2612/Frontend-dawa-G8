import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { Cliente } from '../../interfaces/cliente';

@Injectable({
  providedIn: 'root'
})
export class ClienteService {

  private myAppUrl: string = environment.endpoint;
  private myApiUrl: string = 'api/Cliente/';

  constructor(private http: HttpClient) { }

  addCliente(cliente: Cliente): Observable<number> {
    return this.http.post<number>(`${this.myAppUrl}${this.myApiUrl}`, cliente);
  }

  getCliente(): Observable<Cliente[]> { 
    return this.http.get<Cliente[]>(`${this.myAppUrl}${this.myApiUrl}`);
  }

  private cliente = { nombreCliente: 'Nombre del Cliente', clienteId: 1 };

  getNombreCliente(): Observable<string> {
    return of(this.cliente.nombreCliente);
  }
  getClienteById(clienteId: number): Observable<Cliente> {
    return this.http.get<Cliente>(`${this.myAppUrl}${this.myApiUrl}${clienteId}`);
  }
 
  modificarCliente(cliente: Cliente): Observable<number>{
    return this.http.put<number>(`${this.myAppUrl}${this.myApiUrl}${cliente.clienteId}`,cliente);
  }
  eliminarCliente(id: number): Observable<void>{
    return this.http.delete<void>(`${this.myAppUrl}${this.myApiUrl}${id}`);
  }
  getClienteT(): Observable<any> { 
    return this.http.get<any>(`${this.myAppUrl}${this.myApiUrl}`);
  }
}
