
import { Proveedor } from "./proveedor";

export interface Productos{
    productoId?: number,
    imagenProducto: string,
    nombreProducto: string,
    cantidad: number,
    precio: number,
    categoria: string,
    descripcion: string,
    proveedorId: number,
    proveedor?: Proveedor,
}