import { EmpresaTransporte } from "./empresaTransporte";


export interface OrdenPago{
    ordenPagoId?: number,
    codigo: number,
    clienteId: string,
    empresaTransporteId: number,
    metodoPago: string,
    total: number,
    subTotal: number,
    totalPagar: number,  
    empresaTransporte?: EmpresaTransporte,
}