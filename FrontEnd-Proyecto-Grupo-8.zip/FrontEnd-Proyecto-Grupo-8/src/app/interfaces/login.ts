import { Cliente } from "./cliente";
import { EmpresaTransporte } from "./empresaTransporte";
import { Proveedor } from "./proveedor";

export interface Login{
    loginId?: number,
    usuario: string,
    contrasenia: string,
    tipoUsuario: string;
    cliente?: 
      Cliente,
   
    proveedor?: Proveedor,
    empresaTransporte?: EmpresaTransporte,

}