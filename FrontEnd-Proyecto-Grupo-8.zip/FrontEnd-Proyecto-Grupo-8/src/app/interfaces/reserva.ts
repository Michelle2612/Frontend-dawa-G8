
export interface Reserva{
reservaId?: number,
codigo: number,
clienteId: string,
saldoTotal: number,
saldoAbonado: number,
total: number,


}