export interface Cliente{
    clienteId?: number;
    nombreCliente: string;
    apellidoCliente: string;
    cedula: number;
    direccion: string;
    fechaNacimiento: Date;
    genero: string;
    correo: string;
    contrasenia: string;
    telefono: string;
    loginId?: number;
}