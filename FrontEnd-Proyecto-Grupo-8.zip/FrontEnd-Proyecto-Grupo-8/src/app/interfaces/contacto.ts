export interface Contacto{
    contactoId?: number,
    nombre: string,
    correo: string,
    asunto: string,
    descripcion: string,


}