import { Cliente } from "./cliente";
import { Productos } from "./productos";
import { Proveedor } from "./proveedor";

export interface SolicitudOrden{
    solicitudOrdenId?: number,
    codigo: number,
    clienteId: number,
    productoId: number;
    total: number,
    metodoPago: string,
    cliente?: Cliente,
    producto?: Productos,
}