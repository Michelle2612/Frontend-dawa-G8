export interface Proveedor{
    proveedorId?: number,
    razon_social: number,
    RUC: number,
    nombreProveedor: string,
    correo: string;
    contrasenia: string,
    telefono: string,
    direccion: string,
    tipo: string,
    loginId?: number,
}