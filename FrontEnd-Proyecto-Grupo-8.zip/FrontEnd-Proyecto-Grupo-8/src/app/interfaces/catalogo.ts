import { Productos } from "./productos";

export interface Catalogo{
    catalogoId?: number,
    productoId: number,
    producto?: Productos,
}