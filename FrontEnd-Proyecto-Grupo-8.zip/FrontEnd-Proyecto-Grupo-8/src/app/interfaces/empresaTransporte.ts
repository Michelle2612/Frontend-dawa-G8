export interface EmpresaTransporte{
    empresaTransporteId?: number,
    num_compania: number,
    ruc: number,
    nombreEmpresa: string,
    correo: string;
    contrasenia: string,
    telefono: string,
    direccion: string,
    loginId?: number,
}