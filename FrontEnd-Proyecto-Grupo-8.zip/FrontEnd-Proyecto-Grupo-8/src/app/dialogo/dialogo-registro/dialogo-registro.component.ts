import {ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogActions, MatDialogClose, MatDialogContent, MatDialogRef, MatDialogTitle } from '@angular/material/dialog';
import { MatIcon } from '@angular/material/icon';

@Component({
  selector: 'app-dialogo-registro',
  standalone: true,
  imports: [
    MatDialogTitle, MatDialogContent, MatDialogActions, MatDialogClose, MatButtonModule, MatIcon


  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './dialogo-registro.component.html',
  styleUrl: './dialogo-registro.component.css'
})
export class DialogoRegistroComponent {
  readonly dialog = inject(MatDialog);
  constructor(private dialogRef: MatDialogRef<DialogoRegistroComponent>) {}

  onCancel(): void {
    this.dialogRef.close(false);
  }

  onConfirm(): void {
    this.dialogRef.close(true);
  }
}
