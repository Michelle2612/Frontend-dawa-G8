import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIcon, MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { RouterLink, RouterOutlet } from '@angular/router';
import { EmpresaTransporte } from '../../interfaces/empresaTransporte';
import { EmpresaService } from '../../services/registros/empresa.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-admin-transporte',
  standalone: true,
  imports: [
    RouterOutlet, RouterLink,
    MatFormFieldModule, MatInputModule, MatTableModule, MatSortModule,
     MatPaginatorModule, MatIcon, MatIconModule
  ],
  templateUrl: './admin-transporte.component.html',
  styleUrl: './admin-transporte.component.css'
})
export class AdminTransporteComponent  {
  data: EmpresaTransporte[] = [];
  paginatedData: EmpresaTransporte[] = [];
  currentPage = 0;
  pageSize = 4;
  totalPages = 0;

  constructor(
    private empresaService: EmpresaService,
    private _snackBar: MatSnackBar,
  ) { }
  ngOnInit(): void {
    this.obtenerEmpresa();
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value.trim().toLowerCase();
    this.paginatedData = this.data
      .filter(empresa => 
        empresa.nombreEmpresa.toLowerCase().includes(filterValue) ||
        empresa.direccion.toLowerCase().includes(filterValue) ||
        empresa.telefono.toLowerCase().includes(filterValue))
      .slice(this.currentPage * this.pageSize, (this.currentPage + 1) * this.pageSize);
  }

  obtenerEmpresa(): void {
    this.empresaService.getEmpresaT().subscribe({
      next: (data: any) => {
        this.data = data.$values;
        this.totalPages = Math.ceil(this.data.length / this.pageSize);
        this.paginateData();
      },
      error: (error) => {
        console.error('Error al agregar lista cliente :', error);
        //this.openSnackBar('Ocurrió un error al agregar la orden de pago.', 'Cerrar');
      }
    });
  }
  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      panelClass: ['custom-snackbar']
    });
  }

  eliminarEmpresa(id?: number ){

    if (id === undefined) {
      this.openSnackBar('El ID no es indefinido', 'Cerrar');
      return;
    }

    this.empresaService.eliminarEmpresa(id).subscribe({
      next: data => {
        this.openSnackBar('Dato eliminado correctamente', 'Cerrar');
        this.obtenerEmpresa();
      },
      error: error => {
        this.openSnackBar('Ocurrió un error.', 'Cerrar');
      },
      complete: () => {
        console.info('Eliminacion de libro completa');
        
      }
    });

  }

  paginateData(): void {
    this.paginatedData = this.data.slice(this.currentPage * this.pageSize, (this.currentPage + 1) * this.pageSize);
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages - 1) {
      this.currentPage++;
      this.paginateData();
    }
  }

  previousPage(): void {
    if (this.currentPage > 0) {
      this.currentPage--;
      this.paginateData();
    }
  }
}

