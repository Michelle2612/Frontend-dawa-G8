import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminTransporteComponent } from './admin-transporte.component';

describe('AdminTransporteComponent', () => {
  let component: AdminTransporteComponent;
  let fixture: ComponentFixture<AdminTransporteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminTransporteComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AdminTransporteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
