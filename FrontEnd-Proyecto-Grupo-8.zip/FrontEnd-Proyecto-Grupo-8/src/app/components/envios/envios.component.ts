import { CommonModule } from '@angular/common';
import { AfterViewInit, Component,  ElementRef,  OnDestroy, OnInit, QueryList, ViewChildren } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-envios',
  standalone: true,
  imports: [RouterLink, RouterOutlet, CommonModule],
  templateUrl: './envios.component.html',
  styleUrl: './envios.component.css'
})
export class EnviosComponent implements AfterViewInit, OnDestroy {
  estadoActual: number = 0;
  intervalId: any;
  estados: string[] = ['Preparando', 'Enviado', 'Entregando', 'Entregado'];
  descripciones: string[] = [
    'Preparando paquete para su envío.',
    'El paquete ha sido enviado y está en camino.',
    'El paquete está próximo a ser entregado.',
    'El paquete ha sido entregado exitosamente.'
  ];
  imagenes: string[] = [
    'assets/imagenes/pe.png',
    'assets/imagenes/a.png',
    'assets/imagenes/c.png',
    'assets/imagenes/en.png'
  ];

  @ViewChildren('circulo', { read: ElementRef }) circulos!: QueryList<ElementRef>;
  @ViewChildren('descripcion', { read: ElementRef }) descripcionElems!: QueryList<ElementRef>;

  ngAfterViewInit(): void {
    this.startAutoUpdate();
  }

  ngOnDestroy(): void {
    clearInterval(this.intervalId);
  }

  startAutoUpdate(): void {
    this.intervalId = setInterval(() => {
      this.estadoActual = (this.estadoActual + 1) % this.imagenes.length;
      this.actualizarEstado();
    }, 5000);
  }

  setEstadoActual(index: number): void {
    this.estadoActual = index;
    this.actualizarEstado();
  }

  actualizarEstado(): void {
    this.circulos.forEach((circulo, index) => {
      if (circulo.nativeElement) {
        circulo.nativeElement.classList.remove('verdoso');
      }
    });

    this.descripcionElems.forEach((descripcion, index) => {
      if (descripcion.nativeElement) {
        descripcion.nativeElement.classList.remove('visible');
      }
    });

    if (this.circulos.toArray()[this.estadoActual] && this.descripcionElems.toArray()[this.estadoActual]) {
      this.circulos.toArray()[this.estadoActual].nativeElement.classList.add('verdoso');
      this.descripcionElems.toArray()[this.estadoActual].nativeElement.classList.add('visible');
    }
  }
}