import { CommonModule } from '@angular/common';
import {AfterViewInit, Component,  Inject, PLATFORM_ID  } from '@angular/core';
import {MatButtonModule} from '@angular/material/button';
import {MatCardModule} from '@angular/material/card';
import {MatGridListModule} from '@angular/material/grid-list';
import { isPlatformBrowser } from '@angular/common';
import { RouterLink, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-body',
  standalone: true,
  imports: [MatCardModule, MatButtonModule, MatGridListModule, CommonModule, RouterLink, RouterOutlet],
  templateUrl: './body.component.html',
  styleUrl: './body.component.css'
})
export class BodyComponent implements AfterViewInit {
  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}

  items = [
    { image: 'assets/imagenes/vestido1.jpg', alt: 'Vestido 1' },
    { image: 'assets/imagenes/jean.jpeg', alt: 'Jean' },
    { image: 'assets/imagenes/camisas.jpg', alt: 'Camisas' },
    { image: 'assets/imagenes/camisa.jpg', alt: 'Camisa' },
    { image: 'assets/imagenes/conjunto.jpg', alt: 'Conjunto' }
  ];
  ngAfterViewInit() {
    if (isPlatformBrowser(this.platformId)) {
      const scrollers = document.querySelectorAll<HTMLElement>(".scroller");

      // If a user hasn't opted in for reduced motion, then we add the animation
      if (!window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
        this.addAnimation(scrollers);
      }
    }
  }

  addAnimation(scrollers: NodeListOf<HTMLElement>) {
    scrollers.forEach((scroller) => {
      // add data-animated="true" to every `.scroller` on the page
      scroller.setAttribute("data-animated", 'true');

      // Make an array from the elements within `.scroller-inner`
      const scrollerInner = scroller.querySelector(".scroller__inner");
      if (scrollerInner) {
        const scrollerContent = Array.from(scrollerInner.children);

        // For each item in the array, clone it
        // add aria-hidden to it
        // add it into the `.scroller-inner`
        scrollerContent.forEach((item) => {
          const duplicatedItem = item.cloneNode(true) as HTMLElement;
          duplicatedItem.setAttribute("aria-hidden", 'true');
          scrollerInner.appendChild(duplicatedItem);
        });
      }
    });
  }
}

