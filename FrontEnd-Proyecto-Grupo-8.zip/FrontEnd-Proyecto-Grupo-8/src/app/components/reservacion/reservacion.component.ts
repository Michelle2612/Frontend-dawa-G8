import { CommonModule } from '@angular/common';
import { AfterViewInit, ChangeDetectionStrategy, Component, signal, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { OrdenCompraService } from '../../services/registros/orden-compra.service';
import { OrdenPago } from '../../interfaces/ordenPago';
import { Productos } from '../../interfaces/productos';
import { SolicitudOrden } from '../../interfaces/solicitudOrden';
import { SolicitudOrdenService } from '../../services/registros/solicitud-orden.service';
import { ClienteService } from '../../services/registros/cliente.service';
import { Cliente } from '../../interfaces/cliente';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { DialogoRegistroComponent } from '../../dialogo/dialogo-registro/dialogo-registro.component';
import { Reserva } from '../../interfaces/reserva';
import { ReservaService } from '../../services/registros/reserva.service';
import {MatExpansionModule} from '@angular/material/expansion';

@Component({
  selector: 'app-reservacion',
  standalone: true,
  imports: [RouterLink, RouterOutlet,  MatFormFieldModule,
    CommonModule,MatInputModule,MatTableModule, MatPaginatorModule, ReactiveFormsModule, 
    MatExpansionModule
    
  
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './reservacion.component.html',
  styleUrl: './reservacion.component.css'
})
export class ReservacionComponent implements AfterViewInit {
  displayedColumns: string[] = ['#', 'NOMBRE', 'CANTIDAD', 'PRECIO'];
  dataSource = new MatTableDataSource<Productos>([]);
  clienteForm: FormGroup;
  cliente: Cliente | null = null;
  nombreCliente: string = '';
  totalPagar: number | null = null;
  saldoTotal: number | null = null; 
  readonly panelOpenState = signal(false);
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }

  constructor(
    private fb: FormBuilder,
    private ordenCompraService: OrdenCompraService,
    private reservaService: ReservaService,
    private router: Router,
    private _snackBar: MatSnackBar,
    private dialog: MatDialog,
  ) {
    this.clienteForm = this.fb.group({
      codigo: ['', Validators.required],
      abono: [0, Validators.required],
      saldoTotal: [{ value: '', disabled: true }, Validators.required],
      totalPagar: [{ value: '', disabled: true }, Validators.required],
      nombreCliente: [{ value: '', disabled: true }, Validators.required],

    });
  }

  ngOnInit(): void {
 
  }



    buscarCliente(event: Event) {
      if (this.clienteForm.invalid) {
        this.openSnackBar('Por favor, complete todos los campos antes de continuar.', 'Cerrar');
        return;
      }
      event.preventDefault();
      const codigo = this.clienteForm.value.codigo;
    
      if (!codigo) {
        console.error('Código no proporcionado.');
        return;
      }
    
      this.ordenCompraService.getOrdenPagoByCodigo(codigo).subscribe({
        next: (result: any) => {
          if (result.ordenPago && result.cliente) {
            this.cliente = result.cliente;
            this.nombreCliente = result.cliente.nombreCliente;
            this.totalPagar = result.ordenPago.totalPagar;
            this.saldoTotal = this.totalPagar;
            this.clienteForm.patchValue({
              nombreCliente: this.nombreCliente,
              totalPagar: this.totalPagar,
              saldoTotal: this.totalPagar
            });
            this.openSnackBar('Cliente encontrado.', 'Cerrar');
            // Maneja los productos si están disponibles
          } else {
            console.error('No se encontró la información.');
          }
        },
        error: (err) => console.error('Error al obtener la orden de pago:', err)
      });
    }
    

    abonar() {
      const abono = this.clienteForm.get('abono')?.value || 0;
      if (this.saldoTotal !== null) {
        let totalPagar = this.saldoTotal - abono;
        totalPagar = totalPagar < 0 ? 0 : totalPagar; // Asegúrate de que no sea negativo
        
        // Limita a dos decimales
        totalPagar = parseFloat(totalPagar.toFixed(2));
        
        this.clienteForm.patchValue({
          totalPagar: totalPagar
        });
      }
    }
    
  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      panelClass: ['custom-snackbar']
    });
  }
  registrarReserva() {
    if (this.clienteForm.invalid) {
      this.openSnackBar('Por favor, complete todos los campos antes de continuar.', 'Cerrar');
      return;
    }
    const dialogRef = this.dialog.open(DialogoRegistroComponent);
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        const orden: Reserva = {
          codigo: this.clienteForm.get('codigo')?.value,
          clienteId: this.clienteForm.get('nombreCliente')?.value,
          saldoTotal: this.clienteForm.get('saldoTotal')?.value,
          saldoAbonado: this.clienteForm.get('abono')?.value,
          total: this.clienteForm.get('totalPagar')?.value,
        
        };
        console.log('Datos del formulario:', orden);
  
        this.reservaService.addReserva(orden).subscribe({
          next: (data) => {
            console.log('Orden de pago agregada:', data);
            this.clienteForm.reset();
          },
          error: (error) => {
            console.error('Error al agregar la orden de pago:', error);
            this.openSnackBar('Ocurrió un error al agregar la orden de pago.', 'Cerrar');
          }
        });
      }
    });
  }
   
}

  /*buscarCliente() {
    
    const codigo = this.clienteForm.value.codigo;

    if (!codigo) {
      console.error('Código no proporcionado.');
      return;
    }

    this.ordenCompraService.getOrdenPagoByCodigo(codigo).subscribe({
      next: (result: any) => {
        if (result.ordenPago && result.cliente) {
          this.nombreCliente = result.cliente.nombreCliente;
          this.totalPagar = result.ordenPago.totalPagar;
          this.saldoTotal = this.totalPagar;
          this.openSnackBar('siii.', 'Cerrar');
          // Maneja los productos si están disponibles
        } else {
          console.error('No se encontró la información.');
        }
      },
      error: (err) => console.error('Error al obtener la orden de pago:', err)
    });
  }*/