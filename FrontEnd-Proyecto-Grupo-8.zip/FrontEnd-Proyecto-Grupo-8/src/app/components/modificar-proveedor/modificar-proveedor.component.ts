import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Component } from '@angular/core';
import { ReactiveFormsModule, FormsModule, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIcon, MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { ActivatedRoute, Router, RouterLink, RouterOutlet } from '@angular/router';
import { ProveedorService } from '../../services/registros/proveedor.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Proveedor } from '../../interfaces/proveedor';

@Component({
  selector: 'app-modificar-proveedor',
  standalone: true,
  imports: [MatButtonModule, MatIcon, ReactiveFormsModule,  CommonModule,MatFormFieldModule,
    MatDatepickerModule,MatSelectModule,FormsModule,MatInputModule,
    MatIcon, HttpClientModule,MatIconModule,MatCardModule,RouterLink, RouterOutlet],
  templateUrl: './modificar-proveedor.component.html',
  styleUrl: './modificar-proveedor.component.css'
})
export class ModificarProveedorComponent {
  clienteForm: FormGroup;
  id: number;

  constructor(
    private proService: ProveedorService,
    private router: Router,
    private aRoute: ActivatedRoute,
    private fb: FormBuilder,
    private _snackBar: MatSnackBar,
    
  ) {
    this.id = Number(this.aRoute.snapshot.paramMap.get('id'));
    this.clienteForm = this.fb.group({
      proveedorId: [{value: '', disabled: true}, Validators.required],
      razon_social: ['', Validators.required],
      RUC: ['', Validators.required],
      nombreProveedor: ['', Validators.required],
      correo: ['', Validators.required],
      contrasenia: ['', Validators.required],
      telefono: ['', Validators.required],
      direccion: ['', Validators.required],
      tipo: ['', Validators.required],

    });
  }

  ngOnInit(): void {
    this.id = Number(this.aRoute.snapshot.paramMap.get('id'));
  
    if (this.id) {
      this.proService.getProveedorById(this.id).subscribe({
        next: (data: Proveedor) => {
          this.clienteForm.patchValue({
            proveedorId: data.proveedorId,
            razon_social: data.razon_social,
            RUC: data.RUC,
            nombreProveedor: data.nombreProveedor,
            correo: data.correo,
            contrasenia: data.contrasenia,
            telefono: data.telefono,
            direccion: data.direccion,
            tipo: data.tipo,
        
          });
        },
        error: (error) => {
          console.error('Error al obtener cliente:', error);
        }
      });
    }
  }
  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      panelClass: ['custom-snackbar']
    });
  }

  modificarProveedor(): void {


    const cliente: Proveedor = {
      proveedorId: this.id,
      razon_social: this.clienteForm.value.razon_social,
      RUC: this.clienteForm.value.RUC,
      nombreProveedor: this.clienteForm.value.nombreProveedor,
      correo: this.clienteForm.value.correo,
      contrasenia: this.clienteForm.value.contrasenia,
      telefono: this.clienteForm.value.telefono,
      direccion: this.clienteForm.value.direccion,
      tipo: this.clienteForm.value.tipo,

    };

    this.proService.modificarProveedor(cliente).subscribe({
      next: () => {
        console.info('Modificación de cliente completa');
        this.openSnackBar('modificado correctamente.', 'Cerrar');
        this.router.navigate(['/adminProveedor']);
      },
      error: () => {
        alert('Ocurrió un error');
      }
    });

    this.clienteForm.reset();
  }
}
