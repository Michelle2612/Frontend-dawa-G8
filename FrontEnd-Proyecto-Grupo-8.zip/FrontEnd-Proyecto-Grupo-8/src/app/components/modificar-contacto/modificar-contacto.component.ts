import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Component } from '@angular/core';
import { ReactiveFormsModule, FormsModule, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIcon, MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { RouterLink, RouterOutlet, ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { Contacto } from '../../interfaces/contacto';
import { ContactoService } from '../../services/registros/contacto.service';

@Component({
  selector: 'app-modificar-contacto',
  standalone: true,
  imports: [MatButtonModule, MatIcon, ReactiveFormsModule,  CommonModule,MatFormFieldModule,
    MatDatepickerModule,MatSelectModule,FormsModule,MatInputModule,
    MatIcon, HttpClientModule,MatIconModule,MatCardModule,RouterLink, RouterOutlet],
  templateUrl: './modificar-contacto.component.html',
  styleUrl: './modificar-contacto.component.css'
})
export class ModificarContactoComponent {
  clienteForm: FormGroup;
  id: number;

  constructor(
    private clienteService: ContactoService,
    private router: Router,
    private aRoute: ActivatedRoute,
    private fb: FormBuilder,
    private _snackBar: MatSnackBar,
    
  ) {
    this.id = Number(this.aRoute.snapshot.paramMap.get('id'));
    this.clienteForm = this.fb.group({
      contactoId: [{value: '', disabled: true}, Validators.required],
      nombre: ['', Validators.required],
      asunto: ['', Validators.required], 
      correo: ['', Validators.required],
      descripcion: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.id = Number(this.aRoute.snapshot.paramMap.get('id'));
  
    if (this.id) {
      this.clienteService.getContactoById(this.id).subscribe({
        next: (data: Contacto) => {
          this.clienteForm.patchValue({
            contactoId: data.contactoId,
            nombre: data.nombre,
            correo: data.correo,
            asunto: data.asunto,
            descripcion: data.descripcion
          });
        },
        error: (error) => {
          console.error('Error al obtener cliente:', error);
        }
      });
    }
  }
  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      panelClass: ['custom-snackbar']
    });
  }

  modificarModificar(): void {


    const cliente: Contacto = {
      contactoId: this.id,
      nombre: this.clienteForm.value.nombre,
      correo: this.clienteForm.value.correo,
      asunto: this.clienteForm.value.asunto,
      descripcion: this.clienteForm.value.descripcion,
    
    };

    this.clienteService.modificarContacto(cliente).subscribe({
      next: () => {
        console.info('Modificación de cliente completa');
        this.openSnackBar('modificado correctamente.', 'Cerrar');
        this.router.navigate(['/adminContacto']);
      },
      error: () => {
        alert('Ocurrió un error');
      }
    });

    this.clienteForm.reset();
  }
}
