import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Component } from '@angular/core';
import { ReactiveFormsModule, FormsModule, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIcon, MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { ActivatedRoute, Router, RouterLink, RouterOutlet } from '@angular/router';
import { ProductosService } from '../../services/registros/productos.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Productos } from '../../interfaces/productos';

@Component({
  selector: 'app-modificar-producto',
  standalone: true,
  imports: [MatButtonModule, MatIcon, ReactiveFormsModule,  CommonModule,MatFormFieldModule,
    MatDatepickerModule,MatSelectModule,FormsModule,MatInputModule,
    MatIcon, HttpClientModule,MatIconModule,MatCardModule,RouterLink, RouterOutlet],
  templateUrl: './modificar-producto.component.html',
  styleUrl: './modificar-producto.component.css'
})
export class ModificarProductoComponent {
  clienteForm: FormGroup;
  id: number;

  constructor(
    private productoService: ProductosService,
    private router: Router,
    private aRoute: ActivatedRoute,
    private fb: FormBuilder,
    private _snackBar: MatSnackBar,
    
  ) {
    this.id = Number(this.aRoute.snapshot.paramMap.get('id'));
    this.clienteForm = this.fb.group({
      productoId: [{value: '', disabled: true}, Validators.required],
      imagenProducto: ['', Validators.required],
      nombreProducto: ['', Validators.required],
      cantidad: ['', Validators.required],
      precio: ['', Validators.required],
      categoria: ['', Validators.required],
      descripcion: ['', Validators.required],
    });
  }

  ngOnInit(): void {
    this.id = Number(this.aRoute.snapshot.paramMap.get('id'));
  
    if (this.id) {
      this.productoService.getProductoById(this.id).subscribe({
        next: (data: Productos) => {
          this.clienteForm.patchValue({
            productoId: data.productoId,
            imagenProducto: data.imagenProducto,
            nombreProducto: data.nombreProducto,
            cantidad: data.cantidad,
            precio: data.precio,
            categoria: data.categoria,
            descripcion: data.descripcion,
            proveedorId: data.proveedorId,
          
          });
        },
        error: (error) => {
          console.error('Error al obtener cliente:', error);
        }
      });
    }
  }
  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      panelClass: ['custom-snackbar']
    });
  }

  modificarProducto(): void {


    const cliente: Productos = {
      productoId: this.id,
      imagenProducto: this.clienteForm.value.imagenProducto,
      nombreProducto: this.clienteForm.value.nombreProducto,
      cantidad: this.clienteForm.value.cantidad,
      precio: this.clienteForm.value.precio,
      categoria: this.clienteForm.value.categoria,
      descripcion: this.clienteForm.value.descripcion,
      proveedorId: this.clienteForm.value.proveedorId
      
    };

    this.productoService.modificarProducto(cliente).subscribe({
      next: () => {
        console.info('Modificación de cliente completa');
        this.openSnackBar('Modificado correctamente.', 'Cerrar');
        this.router.navigate(['/adminProducto']);
      },
      error: () => {
        alert('Ocurrió un error');
      }
    });

    this.clienteForm.reset();
  }
}
