import { Component } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { FormBuilder, FormGroup, FormsModule, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatCardModule } from '@angular/material/card';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatInputModule } from '@angular/material/input'; 
import { MatIcon } from '@angular/material/icon';
import { HttpClientModule } from '@angular/common/http';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { DialogoRegistroComponent } from '../../dialogo/dialogo-registro/dialogo-registro.component';
import { ProductosService } from '../../services/registros/productos.service';
import { Productos } from '../../interfaces/productos';
import { Proveedor } from '../../interfaces/proveedor';
import { ProveedorService } from '../../services/registros/proveedor.service';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-producto',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatSelectModule,
    MatCardModule,
    RouterLink,
    RouterOutlet,
    FormsModule,
    MatInputModule,
    MatIcon,
    MatDialogModule,
    HttpClientModule,
    MatButtonModule 
  ],
  templateUrl: './producto.component.html',
  styleUrl: './producto.component.css'
})
export class ProductoComponent {
  clienteForm: FormGroup;
  listaProveedor: Proveedor[] = [];
  imagenPreview: string | ArrayBuffer | null = '../assets/imagenes/vestido1.jpg';
  imagenBase64: string | null = null;

  constructor(
    private _productoService: ProductosService,
    private _proveedorService: ProveedorService,
    private fb: FormBuilder, 
    private router: Router,
    private _snackBar: MatSnackBar,
    private dialog: MatDialog,) {
      this.clienteForm = this.fb.group({
        imagenProducto: [null, Validators.required],
        nombreProducto: ['', Validators.required],
        cantidad: ['', Validators.required],
        precio : ['', [Validators.required]],
        categoria: ['', Validators.required],
        descripcion: ['', Validators.required], 
        proveedorId: ['', Validators.required],
      });
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      panelClass: ['custom-snackbar']
    });
  }

  ngOnInit(): void {
    this.listaProveedores();
  }

  
  listaProveedores(): void {
    this._proveedorService.getPorveedor().subscribe({
      next: (data: any) => { // Cambiar el tipo a 'any' para manejar la estructura anidada
        console.log('Datos recibidos:', data);
        this.listaProveedor = data.$values; // Extraer los proveedores desde $values
      },
      error: error => {
        this.openSnackBar('Ocurrió un error al obtener los proveedores.', 'Cerrar');
      },
      complete: () => {
        console.info('Obtención de proveedores completa');
      }
    });
  }

  registrarProducto() {
    if (this.clienteForm.invalid) {
      this.openSnackBar('Por favor, complete todos los campos antes de continuar.', 'Cerrar');
      return;
    }
    const dialogRef = this.dialog.open(DialogoRegistroComponent);
    dialogRef.afterClosed().subscribe(result => {
    if (result) {
    const producto = {
      imagenProducto: this.imagenBase64 || '', // Enviar imagen en base64
      nombreProducto: this.clienteForm.value.nombreProducto,
      cantidad: this.clienteForm.value.cantidad,
      precio: this.clienteForm.value.precio,
      categoria: this.clienteForm.value.categoria,
      descripcion: this.clienteForm.value.descripcion,
      proveedorId: this.clienteForm.value.proveedorId,
    };

    this._productoService.addProducto(producto).subscribe({
      next: (data) => {
        console.log(data);
        this.clienteForm.reset();
        this.imagenPreview = '../assets/imagenes/vestido1.jpg';
        this.imagenBase64 = null;
      },
      error: (error) => {
        console.error('Error al agregar el producto:', error);
        this.openSnackBar('Ocurrió un error al agregar el producto.', 'Cerrar');
      }
    });
  }
});
}
  
 /* registrarProducto() {
    if (this.clienteForm.invalid) {
      this.openSnackBar('Por favor, complete todos los campos antes de continuar.', 'Cerrar');
      return;
    }

    const dialogRef = this.dialog.open(DialogoRegistroComponent);

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        const productos: Productos = {
          imagenProducto: this.imagenFile,
          nombreProducto: this.clienteForm.value.nombreProducto,
          cantidad: this.clienteForm.value.cantidad,
          precio: this.clienteForm.value.precio,
          categoria: this.clienteForm.value.categoria,
          descripcion: this.clienteForm.value.descripcion,
          proveedorId: this.clienteForm.value.proveedorId,

        };

        console.log('Datos a enviar:', productos); // Añadir mensaje de depuración

        this._productoService.addProducto(productos).subscribe({
          next: data => {
            console.log(data);
            //this.openSnackBar('Cliente agregado correctamente.', 'Cerrar');
            this.clienteForm.reset(); 
            this.imagenPreview = '../assets/imagenes/vestido1.jpg'; 
            this.imagenFile = null; 
          },
          error: error => {
            console.error('Error al agregar el cliente:', error);
            this.openSnackBar('Ocurrió un error al agregar el cliente.', 'Cerrar');
          },
          complete: () => {
            console.info('Agregar cliente completado');
          }
        });
      }
    });
  }*/


  hide = true;
  clickEvent(event: MouseEvent) {
    event.preventDefault(); 
    this.hide = !this.hide;
    event.stopPropagation();
  }
  /*onFileChange(event: any) {
    const file = event.target.files[0];
    if (file) {
      this.imagenFile = file;
      const reader = new FileReader();
      reader.onload = () => {
        this.imagenPreview = reader.result as string;
      };
      reader.readAsDataURL(file);
    }
  }*/
    onFileChange(event: any) {
      const file = event.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = () => {
          this.imagenPreview = reader.result;
          this.imagenBase64 = (reader.result as string).split(',')[1]; // Obtener solo la parte base64
        };
        reader.readAsDataURL(file);
      }
    }
    
  
}
