import { Component } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import {MatSelectModule} from '@angular/material/select';
import {MatFormFieldModule} from '@angular/material/form-field';
import { MatGridListModule } from '@angular/material/grid-list';
import {MatIconModule} from '@angular/material/icon';
import {MatDividerModule} from '@angular/material/divider';
import {MatButtonModule} from '@angular/material/button';
import {MatCardModule} from '@angular/material/card';
import { ProductosService } from '../../services/registros/productos.service';
import { CatalogoService } from '../../services/registros/catalogo.service';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Catalogo } from '../../interfaces/catalogo';
import { Productos } from '../../interfaces/productos';
import { CommonModule } from '@angular/common';
import {MatBadgeModule} from '@angular/material/badge';
import { SolicitudOrdenService } from '../../services/registros/solicitud-orden.service';
import { SolicitudOrden } from '../../interfaces/solicitudOrden';

@Component({
  selector: 'app-catalogo',
  standalone: true,
  imports: [RouterLink, RouterOutlet, MatFormFieldModule, MatSelectModule, MatGridListModule, MatIconModule, MatDividerModule, MatButtonModule, MatCardModule,ReactiveFormsModule,CommonModule, MatCardModule, MatBadgeModule,],
  templateUrl: './catalogo.component.html',
  styleUrl: './catalogo.component.css'
})
export class CatalogoComponent {
  selected = '';
  catalogoForm: FormGroup;
  productos: Productos[] = [];
  badgeCount: number = 0; 
carrito: Productos[] = [];

  constructor(
    private _productoService: ProductosService,
    private fb: FormBuilder,
    private router: Router,
    private solicitudOrdenService: SolicitudOrdenService 
  ) {
    this.catalogoForm = this.fb.group({
      productoId: ['']
    });
  }

  ngOnInit(): void {
    this.loadCatalogo();
    this.solicitudOrdenService.getProductos().subscribe(productos => {
      this.badgeCount = productos.length;
    });
  }

  loadCatalogo(): void {
    if (this.selected) {
      this._productoService.getProductosByCategoria(this.selected).subscribe({
        next: (response: any) => {
          console.log('Datos recibidos:', response);
          if (response && response.$values && Array.isArray(response.$values)) {
            this.productos = response.$values.map((producto: Productos) => ({
              ...producto,
              imagenProducto: producto.imagenProducto // No modificar la cadena base64
            }));
            console.log('Productos:', this.productos); // Agrega este console.log
          } else {
            console.error('Los datos recibidos no contienen un array en $values:', response);
          }
        },
        error: (error) => {
          console.error('Error al obtener productos por categoría:', error);
        }
      });
    }
  }

    getImageUrl(producto: Productos): string {
      console.log(`Obteniendo URL de imagen para el producto: ${producto.productoId}`);
      if (producto.imagenProducto) {  
        return `data:image/jpeg;base64,${producto.imagenProducto}`;
      } else {
        return ''; 
      }
    }
    agregarAlCarrito(producto: Productos): void {
      this.solicitudOrdenService.agregarProducto(producto);
      this.badgeCount++; // Aumentar el contador del badge
    }
  
    irASolicitud(): void {
      this.router.navigate(['/solicitud'], {
        state: { carrito: this.solicitudOrdenService.getProductosSnapshot() }
      });
    }
}
