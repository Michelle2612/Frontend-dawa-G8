import { Component } from '@angular/core';
import { Contacto } from '../../interfaces/contacto';
import { ContactoService } from '../../services/registros/contacto.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIcon, MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { RouterOutlet, RouterLink, RouterModule } from '@angular/router';

@Component({
  selector: 'app-admin-contacto',
  standalone: true,
  imports: [RouterOutlet, RouterLink,
    MatFormFieldModule, MatInputModule, 
    MatIcon, MatIconModule, RouterModule,MatDialogModule],
  templateUrl: './admin-contacto.component.html',
  styleUrl: './admin-contacto.component.css'
})
export class AdminContactoComponent {
  data: Contacto[] = [];
  paginatedData: Contacto[] = [];
  currentPage = 0;
  pageSize = 4;
  totalPages = 0;

  constructor(
    private contactoService: ContactoService,
    private _snackBar: MatSnackBar,
  ) { }
  ngOnInit(): void {
    this.obtenerContacto();
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value.trim().toLowerCase();
    this.paginatedData = this.data
      .filter(cliente => 
        cliente.nombre.toLowerCase().includes(filterValue) ||
        cliente.correo.toLowerCase().includes(filterValue) ||
        cliente.asunto.toLowerCase().includes(filterValue) ||
        cliente.descripcion.toLowerCase().includes(filterValue))
      .slice(this.currentPage * this.pageSize, (this.currentPage + 1) * this.pageSize);
  }

  obtenerContacto(): void {
    this.contactoService.getContactoT().subscribe({
      next: (data: any) => {
        this.data = data.$values;
        this.totalPages = Math.ceil(this.data.length / this.pageSize);
        this.paginateData();
      },
      error: (error) => {
        console.error('Error al agregar lista cliente :', error);
        //this.openSnackBar('Ocurrió un error al agregar la orden de pago.', 'Cerrar');
      }
    });
  }
  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      panelClass: ['custom-snackbar']
    });
  }

  eliminarContacto(id?: number ){

    if (id === undefined) {
      this.openSnackBar('El ID no es indefinido', 'Cerrar');
      return;
    }

    this.contactoService.eliminarContacto(id).subscribe({
      next: data => {
        this.openSnackBar('Dato eliminado correctamente', 'Cerrar');
        this.obtenerContacto();
      },
      error: error => {
        this.openSnackBar('Ocurrió un error.', 'Cerrar');
      },
      complete: () => {
        console.info('Eliminacion de libro completa');
        
      }
    });

  }

  paginateData(): void {
    this.paginatedData = this.data.slice(this.currentPage * this.pageSize, (this.currentPage + 1) * this.pageSize);
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages - 1) {
      this.currentPage++;
      this.paginateData();
    }
  }

  previousPage(): void {
    if (this.currentPage > 0) {
      this.currentPage--;
      this.paginateData();
    }
  }
}
