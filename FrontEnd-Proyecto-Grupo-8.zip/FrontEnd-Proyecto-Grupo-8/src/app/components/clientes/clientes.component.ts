import { Component, inject } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatSelectModule } from '@angular/material/select';
import { MatCardModule } from '@angular/material/card';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { provideNativeDateAdapter } from '@angular/material/core';
import { MatInputModule } from '@angular/material/input'; 
import { MatIcon, MatIconModule } from '@angular/material/icon';
import { ClienteService } from '../../services/registros/cliente.service';
import { Cliente } from '../../interfaces/cliente';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { DialogoRegistroComponent } from '../../dialogo/dialogo-registro/dialogo-registro.component';
import { HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-clientes',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatDatepickerModule,
    MatSelectModule,
    MatCardModule,
    RouterLink,
    RouterOutlet,
    FormsModule,
    MatInputModule,
    MatIcon,
    MatIconModule,
    MatDialogModule,
    HttpClientModule 
  ],
  providers: [provideNativeDateAdapter()],
  templateUrl: './clientes.component.html',
  styleUrls: ['./clientes.component.css']
})
export class ClientesComponent {
  clienteForm: FormGroup;
  constructor(private fb: FormBuilder, 
    private _clienteService: ClienteService,
    private router: Router,
    private _snackBar: MatSnackBar,
    private dialog: MatDialog,
   ) {
    this.clienteForm = this.fb.group({
      nombreCliente: ['', Validators.required],
      apellidoCliente: ['', Validators.required],
      cedula: ['', [Validators.required]],
      direccion: ['', Validators.required],
      fechaNacimiento: ['', Validators.required], 
      genero: ['', Validators.required],
      contrasenia: ['', Validators.required],
      correo: ['', [Validators.required, Validators.email]],
      telefono: ['', Validators.required],
    });
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      panelClass: ['custom-snackbar']
    });
  }
  registrarCliente() {
    if (this.clienteForm.invalid) {
      this.openSnackBar('Por favor, complete todos los campos antes de continuar.', 'Cerrar');
      return;
    }

    const dialogRef = this.dialog.open(DialogoRegistroComponent);

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        const cliente: Cliente = {
          nombreCliente: this.clienteForm.value.nombreCliente,
          apellidoCliente: this.clienteForm.value.apellidoCliente,
          cedula: this.clienteForm.value.cedula,
          direccion: this.clienteForm.value.direccion,
          fechaNacimiento: this.clienteForm.value.fechaNacimiento,
          genero: this.clienteForm.value.genero,
          correo: this.clienteForm.value.correo,
          contrasenia: this.clienteForm.value.contrasenia,
          telefono: this.clienteForm.value.telefono
        };

        console.log('Datos a enviar:', cliente); // Añadir mensaje de depuración

        this._clienteService.addCliente(cliente).subscribe({
          next: data => {
            console.log(data);
            //this.openSnackBar('Cliente agregado correctamente.', 'Cerrar');
            this.clienteForm.reset(); // Resetea el formulario solo después de un guardado exitoso
          },
          error: error => {
            console.error('Error al agregar el cliente:', error);
            this.openSnackBar('Ocurrió un error al agregar el cliente.', 'Cerrar');
          },
          complete: () => {
            console.info('Agregar cliente completado');
          }
        });
      }
    });
  }

  /*registrarCliente() {
    if (this.clienteForm.invalid) {
      this.openSnackBar('Por favor, complete todos los campos antes de continuar.', 'Cerrar');
      return;
    }
    const cliente: Cliente = {
      nombreCliente: this.clienteForm.value.nombreCliente,
      apellidoCliente: this.clienteForm.value.apellidoCliente,
      cedula: this.clienteForm.value.cedula,
      direccion: this.clienteForm.value.direccion,
      fechaNacimiento: this.clienteForm.value.fechaNacimiento,
      genero: this.clienteForm.value.genero,
      correo: this.clienteForm.value.correo,
      contrasenia: this.clienteForm.value.contrasenia,
      telefono: this.clienteForm.value.telefono
    };

    this._clienteService.addCliente(cliente).subscribe({
      next: data => {
        console.log(data);
        this.openSnackBar('Cliente agregado correctamente.', 'Cerrar');
      },
      error: error => {
        this.openSnackBar('Ocurrió un error al agregar el cliente.', 'Cerrar');
      },
      complete: () => {
        console.info('Agregar cliente completa');
        this.openSnackBar('Cliente registrado correctamente.', 'Cerrar');
      }
    });
    this.clienteForm.reset(); 
  }*/


  hide = true;
  clickEvent(event: MouseEvent) {
    event.preventDefault(); 
    this.hide = !this.hide;
    event.stopPropagation();
  }
}

