import { Component } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { FormBuilder, FormGroup, FormsModule, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatCardModule } from '@angular/material/card';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { DialogoRegistroComponent } from '../../dialogo/dialogo-registro/dialogo-registro.component';
import { MatInputModule } from '@angular/material/input'; 
import { MatIcon } from '@angular/material/icon';
import { HttpClientModule } from '@angular/common/http';
import { ProveedorService } from '../../services/registros/proveedor.service';
import { Proveedor } from '../../interfaces/proveedor';

@Component({
  selector: 'app-proveedor',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatSelectModule,
    MatCardModule,
    RouterLink,
    RouterOutlet,
    FormsModule,
    MatInputModule,
    MatIcon,
    MatDialogModule,
    HttpClientModule 
  ],

  templateUrl: './proveedor.component.html',
  styleUrl: './proveedor.component.css'
})
export class ProveedorComponent {
  clienteForm: FormGroup;

  constructor(
    private _proveedorService: ProveedorService,
    private fb: FormBuilder, 
    private router: Router,
    private _snackBar: MatSnackBar,
    private dialog: MatDialog,) {
      this.clienteForm = this.fb.group({
        razon_social: ['', Validators.required],
        ruc: ['', Validators.required],
        nombreProveedor : ['', [Validators.required]],
        correo: ['', Validators.required],
        contrasenia: ['', Validators.required], 
        telefono: ['', Validators.required],
        direccion: ['', Validators.required],
        tipo: ['', [Validators.required]],
      });
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      panelClass: ['custom-snackbar']
    });
  }

  registrarProvedor() {
    if (this.clienteForm.invalid) {
      this.openSnackBar('Por favor, complete todos los campos antes de continuar.', 'Cerrar');
      return;
    }

    const dialogRef = this.dialog.open(DialogoRegistroComponent);

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        const proveedor: Proveedor = {
          razon_social: this.clienteForm.value.razon_social,
          RUC: this.clienteForm.value.ruc,
          nombreProveedor: this.clienteForm.value.nombreProveedor,
          correo: this.clienteForm.value.correo,
          contrasenia: this.clienteForm.value.contrasenia,
          telefono: this.clienteForm.value.telefono,
          direccion: this.clienteForm.value.direccion,
          tipo: this.clienteForm.value.tipo,

        };

        console.log('Datos a enviar:', proveedor); // Añadir mensaje de depuración

        this._proveedorService.addProveedor(proveedor).subscribe({
          next: data => {
            console.log(data);
            //this.openSnackBar('Cliente agregado correctamente.', 'Cerrar');
            this.clienteForm.reset(); // Resetea el formulario solo después de un guardado exitoso
          },
          error: error => {
            console.error('Error al agregar el cliente:', error);
            this.openSnackBar('Ocurrió un error al agregar el cliente.', 'Cerrar');
          },
          complete: () => {
            console.info('Agregar cliente completado');
          }
        });
      }
    });
  }
  hide = true;
  clickEvent(event: MouseEvent) {
    event.preventDefault(); 
    this.hide = !this.hide;
    event.stopPropagation();
  }
}
