import { ChangeDetectionStrategy, Component, Inject, inject } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIcon, MatIconModule } from '@angular/material/icon';
import { ClienteService } from '../../services/registros/cliente.service';
import { ActivatedRoute, Router, RouterLink, RouterModule, RouterOutlet } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CommonModule } from '@angular/common';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { Cliente } from '../../interfaces/cliente';
import { MatCardModule } from '@angular/material/card';
import { HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-modificar-cliente',
  standalone: true,
  imports: [  MatButtonModule, MatIcon, ReactiveFormsModule,  CommonModule,MatFormFieldModule,
    MatDatepickerModule,MatSelectModule,FormsModule,MatInputModule,
    MatIcon, HttpClientModule,MatIconModule,MatCardModule,RouterLink, RouterOutlet],

  templateUrl: './modificar-cliente.component.html',
  styleUrl: './modificar-cliente.component.css'
})
export class ModificarClienteComponent {

  clienteForm: FormGroup;
  id: number;

  constructor(
    private clienteService: ClienteService,
    private router: Router,
    private aRoute: ActivatedRoute,
    private fb: FormBuilder,
    private _snackBar: MatSnackBar,
    
  ) {
    this.id = Number(this.aRoute.snapshot.paramMap.get('id'));
    this.clienteForm = this.fb.group({
      clienteId: [{value: '', disabled: true}, Validators.required],
      nombreCliente: ['', Validators.required],
      apellidoCliente: ['', Validators.required],
      cedula: ['', Validators.required],
      direccion: ['', Validators.required],
      fechaNacimiento: ['', Validators.required],
      genero: ['', Validators.required],
      contrasenia: ['', Validators.required],
      correo: ['', Validators.required],
      telefono: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.id = Number(this.aRoute.snapshot.paramMap.get('id'));
  
    if (this.id) {
      this.clienteService.getClienteById(this.id).subscribe({
        next: (data: Cliente) => {
          this.clienteForm.patchValue({
            clienteId: data.clienteId,
            nombreCliente: data.nombreCliente,
            apellidoCliente: data.apellidoCliente,
            cedula: data.cedula,
            direccion: data.direccion,
            fechaNacimiento: data.fechaNacimiento,
            genero: data.genero,
            correo: data.correo,
            contrasenia: data.contrasenia,
            telefono: data.telefono
          });
        },
        error: (error) => {
          console.error('Error al obtener cliente:', error);
        }
      });
    }
  }
  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      panelClass: ['custom-snackbar']
    });
  }

  modificarCliente(): void {


    const cliente: Cliente = {
      clienteId: this.id,
      nombreCliente: this.clienteForm.value.nombreCliente,
      apellidoCliente: this.clienteForm.value.apellidoCliente,
      cedula: this.clienteForm.value.cedula,
      direccion: this.clienteForm.value.direccion,
      fechaNacimiento: this.clienteForm.value.fechaNacimiento,
      genero: this.clienteForm.value.genero,
      correo: this.clienteForm.value.correo,
      contrasenia: this.clienteForm.value.contrasenia,
      telefono: this.clienteForm.value.telefono
    };

    this.clienteService.modificarCliente(cliente).subscribe({
      next: () => {
        console.info('Modificación de cliente completa');
        this.openSnackBar('modificado correctamente.', 'Cerrar');
        this.router.navigate(['/adminCliente']);
      },
      error: () => {
        alert('Ocurrió un error');
      }
    });

    this.clienteForm.reset();
  }
}