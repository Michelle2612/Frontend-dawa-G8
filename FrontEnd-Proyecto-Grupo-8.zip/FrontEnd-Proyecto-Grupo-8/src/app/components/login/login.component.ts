import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, NgModel, ReactiveFormsModule, Validators } from '@angular/forms';
import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router, RouterLink,  RouterOutlet } from '@angular/router';
import { LoginService } from '../../services/login/login.service';
import { HttpClientModule } from '@angular/common/http';
import { AuthService } from '../../services/login/auth.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [RouterLink, RouterOutlet,CommonModule,ReactiveFormsModule,HttpClientModule],
  templateUrl: './login.component.html',
  styleUrls: [
    './login.component.scss',
    'login-animation.component.scss'
  ]
})
export class LoginComponent  implements   AfterViewInit {


  @ViewChild('slideShape', { static: true }) slideShape!: ElementRef;

  ngAfterViewInit() {
    const element = this.slideShape.nativeElement;
    const backgroundImage = element.getAttribute('data-background-image');
    if (backgroundImage) {
      element.style.backgroundImage = `url(${backgroundImage})`;
    }
  }
  form: FormGroup;
  error: string | null = null;
  showingPage: string = 'account-page';
  isClienteLoggedIn: boolean = false;

  private readonly adminEmail = 'admin@domain.com'; // Correo del administrador
  private readonly adminPassword = 'admin123'; // Contraseña del administrador
  
  constructor(  private _loginService: LoginService,
    private _authService: AuthService,
    private router: Router,
    private fb: FormBuilder,
    private _snackBar: MatSnackBar,

  ) {

    this.form = this.fb.group({
   
      correo: ['', Validators.required],
      contrasenia: ['', Validators.required],
    })
  }
  ngOnInit(): void {
    this._authService.user$.subscribe(user => {
      this.isClienteLoggedIn = user?.tipoUsuario === 'Cliente';
      this.isClienteLoggedIn = user?.tipoUsuario === 'Proveedor';
      this.isClienteLoggedIn = user?.tipoUsuario === 'EmpresaTransporte';
    });
  }

  toggleView(): void {
    this.showingPage = this.showingPage == 'login-page' ? 'account-page' : 'login-page';
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      panelClass: ['custom-snackbar']
    });
  }

  metodoLogin(): void {

    if (this.form.invalid) {
      this.openSnackBar('Por favor, complete todos los campos antes de continuar.', 'Cerrar');
      return;
    }
    const correo = this.form.get('correo')?.value;
    const contrasenia = this.form.get('contrasenia')?.value;

    if (correo === this.adminEmail && contrasenia === this.adminPassword) {
      // Redirigir al componente de administrador
      this.router.navigate(['/admin']);
      return;
    }

    this._loginService.login(correo, contrasenia).subscribe({
      next: (response) => {
        this._authService.setUser(response);
        if (response.tipoUsuario === 'Cliente') {
          this.router.navigate(['/catalogo']);
        } else if (response.tipoUsuario === 'Proveedor') {
          this.router.navigate(['/producto']);
        } else if (response.tipoUsuario === 'EmpresaTransporte') {
          this.router.navigate(['/transporte']);
        }
      },
      error: (err) => {
        this.error = 'Error al iniciar sesión. Verifique sus credenciales.';
      }
    });
  }


  /*metodoLogin(): void{
    const correo = this.form.get('correo')?.value;
    const contrasenia = this.form.get('contrasenia')?.value;
    
    console.log('Correo:', correo);
    console.log('Contrasenia:', contrasenia);
  
    this._loginService.login(correo, contrasenia).subscribe({
      next: (response) => {
        console.log('Login Response:', response);
        this._authService.setUser(response);
        if (response.tipoUsuario === 'Cliente') {
          this.router.navigate(['/catalogo']); 
        } else if (response.tipoUsuario === 'Proveedor') {
          this.router.navigate(['/producto']);
        } else if (response.tipoUsuario === 'EmpresaTransporte') {
          this.router.navigate(['/transporte']);
        }
      },
      error: (err) => {
        console.error('Error:', err);
        this.error = 'Error al iniciar sesión. Verifique sus credenciales.';
      }
    });
  }*/
}


