import { Component } from '@angular/core';

import { RouterLink, RouterOutlet } from '@angular/router';
import {MatButtonModule} from '@angular/material/button';
import {MatSelectModule} from '@angular/material/select';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatSidenavModule} from '@angular/material/sidenav';

@Component({
  selector: 'app-administrador',
  standalone: true,
  imports: [RouterOutlet, RouterLink,
    MatSidenavModule, MatFormFieldModule, 
    MatSelectModule, MatButtonModule
  ],
  templateUrl: './administrador.component.html',
  styleUrl: './administrador.component.css'
})
export class AdministradorComponent {

}
