import { Component } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { DialogoRegistroComponent } from '../../dialogo/dialogo-registro/dialogo-registro.component';
import { ContactoService } from '../../services/registros/contacto.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { Contacto } from '../../interfaces/contacto';
@Component({
  selector: 'app-contacto',
  standalone: true,
  imports: [RouterLink, RouterOutlet,
    CommonModule,
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatButtonModule
  ],
  templateUrl: './contacto.component.html',
  styleUrl: './contacto.component.css'
})
export class ContactoComponent {
  contactForm: FormGroup; // Declaración de la propiedad
  showSuccessMessage: boolean = false;

  constructor(
    private _contactoService: ContactoService,
    private router: Router,
    private _snackBar: MatSnackBar,
    private dialog: MatDialog,
    private fb: FormBuilder) {
    this.contactForm = this.fb.group({
      nombre: ['', Validators.required],
      correo: ['', [Validators.required, Validators.email]],
      asunto: ['', Validators.required],
      descripcion: ['', Validators.required],
    });
  }

  ngOnInit(): void {}
  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      panelClass: ['custom-snackbar']
    });
  }
  enviarMensaje() {
    if (this.contactForm.invalid) {
      this.openSnackBar('Por favor, complete todos los campos antes de continuar.', 'Cerrar');
      return;
    }

    const dialogRef = this.dialog.open(DialogoRegistroComponent);

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        const contacto: Contacto = {
          nombre: this.contactForm.value.nombre,
          correo: this.contactForm.value.correo,
          asunto: this.contactForm.value.asunto,
          descripcion: this.contactForm.value.descripcion,
        };

        console.log('Datos a enviar:', contacto); // Añadir mensaje de depuración

        this._contactoService.addContacto(contacto).subscribe({
          next: data => {
            console.log(data);
            //this.openSnackBar('Cliente agregado correctamente.', 'Cerrar');
            this.contactForm.reset(); // Resetea el formulario solo después de un guardado exitoso
          },
          error: error => {
            console.error('Error al agregar el cliente:', error);
            this.openSnackBar('Ocurrió un error al agregar el cliente.', 'Cerrar');
          },
          complete: () => {
            console.info('Agregar cliente completado');
          }
        });
      }
    });
  }

}
