import { Component } from '@angular/core';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatTabsModule} from '@angular/material/tabs';
import {MatMenuModule} from '@angular/material/menu';
import {MatButtonModule} from '@angular/material/button';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { AuthService } from '../../services/login/auth.service';
import { Login } from '../../interfaces/login';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

export interface Tile {
  color: string;
  cols: number;
  rows: number;
  text: string;
}

@Component({
  selector: 'app-header',
  standalone: true,
  
  imports: [MatGridListModule,MatTabsModule, MatButtonModule, MatMenuModule, RouterLink, RouterOutlet, CommonModule, HttpClientModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {
  user: Login | null = null;

  constructor(private authService: AuthService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.authService.user$.subscribe(user => {
      this.user = user;
    });
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/body']);
  }
  isButtonDisabled(): boolean {
    return this.authService.isAuthenticated() && this.authService.isCliente();
  }
}
