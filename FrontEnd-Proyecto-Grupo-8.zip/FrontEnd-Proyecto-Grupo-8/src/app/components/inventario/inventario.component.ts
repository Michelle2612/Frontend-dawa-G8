import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIcon, MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule, MatPaginator } from '@angular/material/paginator';
import { MatSortModule, MatSort } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { RouterLink, RouterOutlet } from '@angular/router';
import { OrdenPago } from '../../interfaces/ordenPago';
import { OrdenCompraService } from '../../services/registros/orden-compra.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-inventario',
  standalone: true,
  imports: [RouterLink, RouterOutlet,
    MatFormFieldModule, MatInputModule, MatTableModule, MatSortModule, MatPaginatorModule,
    MatIcon, MatIconModule
  ],
  templateUrl: './inventario.component.html',
  styleUrl: './inventario.component.css'
})
export class InventarioComponent  {
  data: OrdenPago[] = [];
  paginatedData: OrdenPago[] = [];
  currentPage = 0;
  pageSize = 4;
  totalPages = 0;

  constructor(
    private ordenService: OrdenCompraService,
    private _snackBar: MatSnackBar,
  ) { }
  ngOnInit(): void {
    this.obtenerOrden();
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value.trim().toLowerCase();
    this.paginatedData = this.data
      .filter(cliente => 
        cliente.clienteId.toLowerCase().includes(filterValue))
      .slice(this.currentPage * this.pageSize, (this.currentPage + 1) * this.pageSize);
  }

  obtenerOrden(): void {
    this.ordenService.getOrdenT().subscribe({
      next: (data: any) => {
        this.data = data.$values;
        this.totalPages = Math.ceil(this.data.length / this.pageSize);
        this.paginateData();
      },
      error: (error) => {
        console.error('Error al agregar lista cliente :', error);
        //this.openSnackBar('Ocurrió un error al agregar la orden de pago.', 'Cerrar');
      }
    });
  }
  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      panelClass: ['custom-snackbar']
    });
  }

  eliminarOrden(id?: number ){

    if (id === undefined) {
      this.openSnackBar('El ID no es indefinido', 'Cerrar');
      return;
    }

    this.ordenService.eliminarOrden(id).subscribe({
      next: data => {
        this.openSnackBar('Dato eliminado correctamente', 'Cerrar');
        this.obtenerOrden();
      },
      error: error => {
        this.openSnackBar('Ocurrió un error.', 'Cerrar');
      },
      complete: () => {
        console.info('Eliminacion de libro completa');
        
      }
    });

  }

  paginateData(): void {
    this.paginatedData = this.data.slice(this.currentPage * this.pageSize, (this.currentPage + 1) * this.pageSize);
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages - 1) {
      this.currentPage++;
      this.paginateData();
    }
  }

  previousPage(): void {
    if (this.currentPage > 0) {
      this.currentPage--;
      this.paginateData();
    }
  }
}
