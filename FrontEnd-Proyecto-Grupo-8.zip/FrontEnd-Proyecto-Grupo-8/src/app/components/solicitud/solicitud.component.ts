import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { SolicitudOrdenService } from '../../services/registros/solicitud-orden.service';
import { Productos } from '../../interfaces/productos';
import { SolicitudOrden } from '../../interfaces/solicitudOrden';
import { Cliente } from '../../interfaces/cliente';
import { Proveedor } from '../../interfaces/proveedor';
import { ClienteService } from '../../services/registros/cliente.service';
import { ProveedorService } from '../../services/registros/proveedor.service';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/login/auth.service';

@Component({
  selector: 'app-solicitud',
  standalone: true,
  imports: [RouterLink, RouterOutlet,  MatFormFieldModule,
    CommonModule,MatInputModule, MatRadioModule, MatTableModule, CommonModule, FormsModule],
  templateUrl: './solicitud.component.html',
  styleUrl: './solicitud.component.css'
})
export class SolicitudComponent {
  displayedColumns: string[] = ['#', 'NOMBRE', 'CANTIDAD', 'PRECIO'];
  dataSource = new MatTableDataSource<Productos>([]);
  total: number = 0;
  nombreCliente: string = '';
  carrito: Productos[] = [];
  metodoPago: string = '';
  codigoGenerativo: string = '';

  constructor(private router: Router, private authService: AuthService) {
    const navigation = this.router.getCurrentNavigation();
    if (navigation?.extras?.state) {
      this.carrito = navigation.extras.state['carrito'] || [];
    }
  }

  ngOnInit(): void {
    this.dataSource.data = this.carrito;
    this.calcularTotal();
    this.cargarNombreCliente();
    this.generarCodigo();
  }

  cargarNombreCliente(): void {
    this.authService.user$.subscribe(user => {
      this.nombreCliente = user?.cliente?.nombreCliente || 'Desconocido';
    });
  }

  calcularTotal(): void {
    this.total = this.carrito.reduce((acc, producto) => acc + producto.precio, 0);
  }

  onMetodoPagoChange(event: any): void {
    this.metodoPago = event.value;
  }

  generarCodigo(): void {
    // Genera un número aleatorio entre 1000 y 9999 (cuatro dígitos)
    const codigo = Math.floor(1000 + Math.random() * 9000);
    this.codigoGenerativo = codigo.toString();
  }

  realizarCompra(): void {
    const navigationData = {
      carrito: this.carrito,
      nombreCliente: this.nombreCliente,
      total: this.total,
      metodoPago: this.metodoPago,
      codigoGenerativo: this.codigoGenerativo
    };
    
    console.log('Datos a enviar:', navigationData);  // Verifica aquí

    this.router.navigate(['/compra'], {
      state: navigationData
    });
  }
}


