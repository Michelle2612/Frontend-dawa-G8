import { Component, ViewChild } from '@angular/core';
import { ActivatedRoute, Router, RouterLink, RouterModule, RouterOutlet } from '@angular/router';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import { MatIcon, MatIconModule } from '@angular/material/icon';
import { Cliente } from '../../interfaces/cliente';
import { ClienteService } from '../../services/registros/cliente.service';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { ModificarClienteComponent } from '../modificar-cliente/modificar-cliente.component';
import { MatSnackBar } from '@angular/material/snack-bar';


@Component({
  selector: 'app-admin-clientes',
  standalone: true,
  imports: [
    RouterOutlet, RouterLink,
    MatFormFieldModule, MatInputModule, 
    MatIcon, MatIconModule, RouterModule,MatDialogModule
  ],
  templateUrl: './admin-clientes.component.html',
  styleUrl: './admin-clientes.component.css'
})
export class AdminClientesComponent  {
  data: Cliente[] = [];
  paginatedData: Cliente[] = [];
  currentPage = 0;
  pageSize = 4;
  totalPages = 0;

  constructor(
    private clienteService: ClienteService,
    private _snackBar: MatSnackBar,
  ) { }
  ngOnInit(): void {
    this.obtenerClientes();
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value.trim().toLowerCase();
    this.paginatedData = this.data
      .filter(cliente => 
        cliente.nombreCliente.toLowerCase().includes(filterValue) ||
        cliente.apellidoCliente.toLowerCase().includes(filterValue) ||
        cliente.direccion.toLowerCase().includes(filterValue) ||
        cliente.genero.toLowerCase().includes(filterValue) ||
        cliente.correo.toLowerCase().includes(filterValue) ||
        cliente.telefono.toLowerCase().includes(filterValue))
      .slice(this.currentPage * this.pageSize, (this.currentPage + 1) * this.pageSize);
  }

  obtenerClientes(): void {
    this.clienteService.getClienteT().subscribe({
      next: (data: any) => {
        this.data = data.$values;
        this.totalPages = Math.ceil(this.data.length / this.pageSize);
        this.paginateData();
      },
      error: (error) => {
        console.error('Error al agregar lista cliente :', error);
        //this.openSnackBar('Ocurrió un error al agregar la orden de pago.', 'Cerrar');
      }
    });
  }
  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      panelClass: ['custom-snackbar']
    });
  }

  eliminarCliente(id?: number ){

    if (id === undefined) {
      this.openSnackBar('El ID no es indefinido', 'Cerrar');
      return;
    }

    this.clienteService.eliminarCliente(id).subscribe({
      next: data => {
        this.openSnackBar('Dato eliminado correctamente', 'Cerrar');
        this.obtenerClientes();
      },
      error: error => {
        this.openSnackBar('Ocurrió un error.', 'Cerrar');
      },
      complete: () => {
        console.info('Eliminacion de libro completa');
        
      }
    });

  }

  paginateData(): void {
    this.paginatedData = this.data.slice(this.currentPage * this.pageSize, (this.currentPage + 1) * this.pageSize);
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages - 1) {
      this.currentPage++;
      this.paginateData();
    }
  }

  previousPage(): void {
    if (this.currentPage > 0) {
      this.currentPage--;
      this.paginateData();
    }
  }
}

