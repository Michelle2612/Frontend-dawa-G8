import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { ActivatedRoute, Router, RouterLink, RouterOutlet } from '@angular/router';
import {MatRadioModule} from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Productos } from '../../interfaces/productos';
import { EmpresaService } from '../../services/registros/empresa.service';
import { EmpresaTransporte } from '../../interfaces/empresaTransporte';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { OrdenCompraService } from '../../services/registros/orden-compra.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { DialogoRegistroComponent } from '../../dialogo/dialogo-registro/dialogo-registro.component';
import { OrdenPago } from '../../interfaces/ordenPago';

@Component({
  selector: 'app-orden-de-compra',
  standalone: true,
  imports: [RouterLink, RouterOutlet,  MatFormFieldModule,
    CommonModule,MatInputModule, MatRadioModule, MatSelectModule, MatTableModule, ReactiveFormsModule,
  ],
  templateUrl: './orden-de-compra.component.html',
  styleUrl: './orden-de-compra.component.css'
})
export class OrdenDeCompraComponent {
  displayedColumns: string[] = ['#', 'NOMBRE', 'CANTIDAD', 'PRECIO'];
  dataSource = new MatTableDataSource<Productos>([]);
  total: number = 0;
  iva: number = 0;
  totalPagar: number = 0;
  nombreCliente: string = '';
  metodoPago: string = '';
  codigo: string = '';
  listaEmpresa: EmpresaTransporte[] = [];
  clienteForm: FormGroup;

  constructor(
    private router: Router,
    private _empresaServices: EmpresaService,
    private _ordenPagoServices: OrdenCompraService,
    private _snackBar: MatSnackBar,
    private dialog: MatDialog,
    private fb: FormBuilder,
  ) {
    this.clienteForm = this.fb.group({
      codigo: [{ value: '', disabled: true }, Validators.required],
      clienteId: ['', Validators.required],
      clienteNombre: [{ value: '', disabled: true }, Validators.required],
      metodoPago: [{ value: '', disabled: true }, Validators.required],
      empresaTransporteId: ['', Validators.required],
      total: [{ value: '', disabled: true }, Validators.required],
      iva: [{ value: '', disabled: true }, Validators.required],
      totalPagar: [{ value: '', disabled: true }, Validators.required]
    });
  }

  ngOnInit(): void {
    this.consultarEmpresa();
    this.initializeData();
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      panelClass: ['custom-snackbar']
    });
  }

  registrarOrden() {
    const dialogRef = this.dialog.open(DialogoRegistroComponent);
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        const orden: OrdenPago = {
          codigo: this.clienteForm.get('codigo')?.value,
          clienteId: this.clienteForm.get('clienteNombre')?.value,
          empresaTransporteId: this.clienteForm.get('empresaTransporteId')?.value,
          metodoPago: this.clienteForm.get('metodoPago')?.value,
          total: this.clienteForm.get('total')?.value,
          subTotal: this.clienteForm.get('iva')?.value,
          totalPagar: this.clienteForm.get('totalPagar')?.value,
        };
        console.log('Datos del formulario:', orden);
  
        this._ordenPagoServices.addOrdenPago(orden).subscribe({
          next: (data) => {
            console.log('Orden de pago agregada:', data);
            this.clienteForm.reset();
          },
          error: (error) => {
            console.error('Error al agregar la orden de pago:', error);
            this.openSnackBar('Ocurrió un error al agregar la orden de pago.', 'Cerrar');
          }
        });
      }
    });
  }
  
  initializeData() {
    const navigation = this.router.getCurrentNavigation();
    if (navigation?.extras?.state) {
      const state = navigation.extras.state as {
        carrito: Productos[];
        nombreCliente: string;
        total: number;
        metodoPago: string;
        codigoGenerativo: string;
      };

      this.dataSource.data = state.carrito || [];
      this.total = state.total || 0;
      this.metodoPago = state.metodoPago || '';
      this.codigo = state.codigoGenerativo || '';
      this.nombreCliente = state.nombreCliente || '';

      this.clienteForm.patchValue({
        codigo: this.codigo,
        clienteNombre: this.nombreCliente,
        total: this.total,
        subTotal: this.total,
        totalPagar: this.totalPagar,
        iva: this.iva,
        metodoPago: this.metodoPago
      });

    } else if (typeof window !== 'undefined' && window.history.state) {
      const state = window.history.state;
      this.dataSource.data = state.carrito || [];
      this.total = state.total || 0;
      this.metodoPago = state.metodoPago || '';
      this.codigo = state.codigoGenerativo || '';
      this.nombreCliente = state.nombreCliente || '';

      this.clienteForm.patchValue({
        codigo: this.codigo,
        clienteNombre: this.nombreCliente,
        total: this.total,
        subTotal: this.total,
        totalPagar: this.totalPagar,
        iva: this.iva,
        metodoPago: this.metodoPago
      });
    }
    this.calculateTotals();
  }

  calculateTotals() {
    this.iva = this.total * 0.15;
    this.totalPagar = this.total + this.iva;

    this.clienteForm.patchValue({
      iva: this.iva,
      totalPagar: this.totalPagar
    });
  }

  consultarEmpresa() {
    this._empresaServices.getEmpresaT().subscribe({
      next: (data: any) => {
        this.listaEmpresa = data.$values;
      },
      error: error => {
        this.openSnackBar('Ocurrió un error al obtener los proveedores.', 'Cerrar');
      },
      complete: () => {
        console.info('Obtención de proveedores completa');
      }
    });
  }
}