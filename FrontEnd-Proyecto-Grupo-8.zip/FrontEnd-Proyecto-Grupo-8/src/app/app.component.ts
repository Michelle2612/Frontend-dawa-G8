import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { HeaderComponent } from "./components/header/header.component";
import { FooterComponent } from "./components/footer/footer.component";
import { LoginComponent } from './components/login/login.component';
import { ClientesComponent } from './components/clientes/clientes.component';
import { ProveedorComponent } from './components/proveedor/proveedor.component';
import { TransporteComponent } from './components/transporte/transporte.component';
import { ProductoComponent } from './components/producto/producto.component';
import { CatalogoComponent } from './components/catalogo/catalogo.component';
import { ContactoComponent } from './components/contacto/contacto.component';
import { AdminProductoComponent } from './components/admin-producto/admin-producto.component';
import { AdminClientesComponent } from './components/admin-clientes/admin-clientes.component';
import { AdministradorComponent } from './components/administrador/administrador.component';
import { AdminProveedorComponent } from './components/admin-proveedor/admin-proveedor.component';
import { AdminTransporteComponent } from './components/admin-transporte/admin-transporte.component';
import { ReservacionComponent } from './components/reservacion/reservacion.component';
import { OrdenDeCompraComponent } from './components/orden-de-compra/orden-de-compra.component';
import { InventarioComponent } from './components/inventario/inventario.component';
import { EnviosComponent } from './components/envios/envios.component';
import { ModificarClienteComponent } from './components/modificar-cliente/modificar-cliente.component';


@Component({
    selector: 'app-root',
    standalone: true,
    templateUrl: './app.component.html',
    styleUrl: './app.component.css',
    imports: [RouterOutlet, RouterLink, 
      HeaderComponent, FooterComponent,
      LoginComponent, ClientesComponent, 
      ProveedorComponent, TransporteComponent, 
      ProductoComponent, CatalogoComponent, 
      ContactoComponent, AdminProductoComponent,
      AdminClientesComponent,AdministradorComponent,
      AdminProveedorComponent, AdminTransporteComponent,
      ReservacionComponent, OrdenDeCompraComponent,
      InventarioComponent, EnviosComponent,
      ModificarClienteComponent]
})
export class AppComponent {
  title = 'FrontEnd-Proyecto-Grupo-8';
}
