import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  matSelectAnimations
} from "./chunk-TZHEG2SG.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-CB3AZOZ6.js";
import "./chunk-DHH6C26F.js";
import "./chunk-UHDKHANM.js";
import "./chunk-HHURTFWW.js";
import "./chunk-YBG3VS72.js";
import "./chunk-APBILN2T.js";
import "./chunk-GRJNHHHF.js";
import {
  MatOptgroup,
  MatOption
} from "./chunk-GMFG7ZVB.js";
import "./chunk-5ABQCTFA.js";
import "./chunk-FH6MQMEX.js";
import "./chunk-V2DXGMIT.js";
import "./chunk-UKEHM6V6.js";
import "./chunk-ZDOIMVJD.js";
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatOptgroup,
  MatOption,
  MatPrefix,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  MatSuffix,
  matSelectAnimations
};
//# sourceMappingURL=@angular_material_select.js.map
